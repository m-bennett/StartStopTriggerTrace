﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StartStopTriggerTrace.Models
{
    public class EquipmentConstant
    {
        public int ecid { get; set; }
        public string type { get; set; }
        public int ecv { get; set; }
    }
}
